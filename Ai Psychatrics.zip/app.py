import gradio as gr

# Import modules from other files
from qdrant import model_inference, chatbot

# Chat interface block
with gr.Blocks(
        css="""
        .gradio-container .avatar-container {height: 40px; width: 40px !important;}
        #duplicate-button {margin: auto; color: white; background: #f1a139; border-radius: 100vh; margin-top: 2px; margin-bottom: 2px;}
        """,
) as chat:
    gr.ChatInterface(
        fn=model_inference,
        chatbot=chatbot,
        multimodal=True,
        autofocus=True,
        concurrency_limit=10,
    )

# Function to handle exercise clicks


# Main application block
with gr.Blocks() as demo:
    gr.TabbedInterface([chat], ['💬 SuperChat'])


demo.queue(max_size=300)
demo.launch(share=True)
